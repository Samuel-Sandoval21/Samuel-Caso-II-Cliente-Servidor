CREATE DATABASE IF NOT EXISTS libreria_digital; 
USE libreria_digital;

DROP TABLE IF EXISTS EventoLibro;
DROP TABLE IF EXISTS Libro;

CREATE TABLE Libro (
    id_libro INT AUTO_INCREMENT PRIMARY KEY,
    isbn VARCHAR(20) UNIQUE NOT NULL,
    titulo VARCHAR(100) NOT NULL,
    autor VARCHAR(100),
    editorial VARCHAR(100),
    fecha_publicacion DATE,
    precio DECIMAL(6 , 2 ),
    stock INT,
    categoria VARCHAR(50),
    descripcion TEXT
);
 
CREATE TABLE EventoLibro (
    id_evento INT AUTO_INCREMENT PRIMARY KEY,
    id_libro INT,
    tipo_evento ENUM('ACTUALIZACION_PRECIO', 'CAMBIO_STOCK', 'RECLASIFICACION') NOT NULL,
    fecha_evento DATE NOT NULL,
    detalles TEXT,
    FOREIGN KEY (id_libro)
        REFERENCES Libro (id_libro)
);
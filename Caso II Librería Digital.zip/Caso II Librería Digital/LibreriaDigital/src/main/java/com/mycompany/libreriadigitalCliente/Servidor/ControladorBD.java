/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.libreriadigitalCliente.Servidor;

import java.sql.*;

/**
 *
 * @author HP
 */
public class ControladorBD {

    private Connection conexion;

    public ControladorBD() {
        try {
            conexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/biblioteca", "usuario", "clave");
        } catch (Exception e) {
            System.err.println("❌ Error al conectar con BD: " + e.getMessage());
        }
    }

    public boolean editarLibro(String isbn, double nuevoPrecio, int nuevoStock) {
        try {
            // Obtener valores actuales
            PreparedStatement psConsulta = conexion.prepareStatement("SELECT id_libro, precio, stock FROM libro WHERE isbn = ?");
            psConsulta.setString(1, isbn);
            ResultSet rs = psConsulta.executeQuery();

            if (!rs.next()) {
                return false; // No se encontró el libro
            }
            int idLibro = rs.getInt("id_libro");
            double precioActual = rs.getDouble("precio");
            int stockActual = rs.getInt("stock");

            // Actualizar valores
            PreparedStatement psUpdate = conexion.prepareStatement("UPDATE libro SET precio=?, stock=? WHERE isbn=?");
            psUpdate.setDouble(1, nuevoPrecio);
            psUpdate.setInt(2, nuevoStock);
            psUpdate.setString(3, isbn);

            boolean actualizado = psUpdate.executeUpdate() > 0;

            // Registrar eventos si hubo cambios
            if (actualizado) {
                if (nuevoPrecio != precioActual) {
                    registrarEvento(idLibro, "Cambio de Precio", "De " + precioActual + " a " + nuevoPrecio);
                }
                if (nuevoStock != stockActual) {
                    registrarEvento(idLibro, "Cambio de Stock", "De " + stockActual + " a " + nuevoStock);
                }
            }

            return actualizado;
        } catch (SQLException e) {
            System.err.println("❌ Error al editar libro: " + e.getMessage());
            return false;
        }
    }

    public boolean eliminarLibro(String isbn) {
        try (PreparedStatement ps = conexion.prepareStatement("DELETE FROM libro WHERE isbn=?")) {
            ps.setString(1, isbn);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            return false;
        }
    }

    public boolean registrarEvento(int idLibro, String tipo, String detalles) {
        try (PreparedStatement ps = conexion.prepareStatement(
                "INSERT INTO evento (id_libro, tipo, detalles, fecha) VALUES (?, ?, ?, NOW())")) {
            ps.setInt(1, idLibro);
            ps.setString(2, tipo);
            ps.setString(3, detalles);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            return false;
        }
    }

    public ResultSet consultarEventos(int idLibro) throws SQLException {
        PreparedStatement ps = conexion.prepareStatement(
                "SELECT fecha, tipo, detalles FROM evento WHERE id_libro=? ORDER BY fecha DESC");
        ps.setInt(1, idLibro);
        return ps.executeQuery();
    }

    public boolean isbnExiste(String isbn) throws SQLException {
        PreparedStatement ps = conexion.prepareStatement("SELECT COUNT(*) FROM Libro WHERE isbn = ?");
        ps.setString(1, isbn);
        ResultSet rs = ps.executeQuery();
        rs.next();
        return rs.getInt(1) > 0;
    }

}

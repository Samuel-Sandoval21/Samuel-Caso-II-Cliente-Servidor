/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.libreriadigitalCliente.Servidor;

import java.net.Socket;

/**
 *
 * @author HP
 */
public class ManejadorCliente extends Thread {

    private Socket cliente;

    public ManejadorCliente(Socket cliente) {
        this.cliente = cliente;
    }

    @Override
    public void run() {
        try {
            Protocolo protocolo = new Protocolo(cliente);
            protocolo.procesar();
            cliente.close();
        } catch (Exception e) {
            System.err.println("❌ Error al manejar cliente: " + e.getMessage());
        }
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.libreriadigitalCliente.Servidor;

import java.io.*;
import java.net.Socket;
import java.sql.ResultSet;

/**
 *
 * @author HP
 */
public class Protocolo {

    private BufferedReader in;
    private PrintWriter out;
    private ControladorBD bd;

    public Protocolo(Socket cliente) throws IOException {
        in = new BufferedReader(new InputStreamReader(cliente.getInputStream()));
        out = new PrintWriter(cliente.getOutputStream(), true);
        bd = new ControladorBD();
    }

    public void procesar() {
        try {
            String comando = in.readLine();

            switch (comando) {
                case "registrar_evento":
                    int idLibro = Integer.parseInt(in.readLine());
                    String tipo = in.readLine();
                    String detalles = in.readLine();
                    boolean eventoOk = bd.registrarEvento(idLibro, tipo, detalles);
                    out.println(eventoOk ? "OK" : "ERROR");
                    break;

                case "editar_libro":
                    String isbnEdit = in.readLine();
                    double precio = Double.parseDouble(in.readLine());
                    int stock = Integer.parseInt(in.readLine());
                    boolean editOk = bd.editarLibro(isbnEdit, precio, stock);
                    out.println(editOk ? "OK" : "ERROR");
                    break;

                case "eliminar_libro":
                    String isbnDel = in.readLine();
                    boolean delOk = bd.eliminarLibro(isbnDel);
                    out.println(delOk ? "OK" : "ERROR");
                    break;

                case "consultar_eventos":
                    int idEv = Integer.parseInt(in.readLine());
                    ResultSet rs = bd.consultarEventos(idEv);
                    while (rs.next()) {
                        out.println(rs.getString("fecha") + ";" + rs.getString("tipo") + ";" + rs.getString("detalles"));
                    }
                    out.println("FIN");
                    break;

                default:
                    out.println("❌ Comando no reconocido");
                    break;
            }
        } catch (Exception e) {
            out.println("❌ Error en protocolo: " + e.getMessage());
        }
    }
}

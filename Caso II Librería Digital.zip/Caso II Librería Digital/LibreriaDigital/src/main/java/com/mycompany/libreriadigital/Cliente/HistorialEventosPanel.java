/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.libreriadigital.Cliente;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.*;
import java.net.Socket;
import javax.swing.JFrame;

/**
 *
 * @author HP
 */
public class HistorialEventosPanel extends JFrame {

    private JTextField tfIdLibro;
    private JTable tabla;
    private JButton btnConsultar;

    public HistorialEventosPanel() {
        setTitle("📊 Historial de Eventos");
        setSize(600, 400);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        tfIdLibro = new JTextField();
        btnConsultar = new JButton("Consultar");

        JPanel top = new JPanel(new BorderLayout());
        top.add(new JLabel("ID Libro:"), BorderLayout.WEST);
        top.add(tfIdLibro, BorderLayout.CENTER);
        top.add(btnConsultar, BorderLayout.EAST);

        tabla = new JTable(new DefaultTableModel(new Object[]{"Fecha", "Tipo", "Detalles"}, 0));

        btnConsultar.addActionListener(e -> consultarEventos());

        add(top, BorderLayout.NORTH);
        add(new JScrollPane(tabla), BorderLayout.CENTER);
    }

    private void consultarEventos() {
        try (Socket socket = new Socket("localhost", 1234); PrintWriter out = new PrintWriter(socket.getOutputStream(), true); BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()))) {

            out.println("consultar_eventos");
            out.println(tfIdLibro.getText());

            DefaultTableModel model = (DefaultTableModel) tabla.getModel();
            model.setRowCount(0); // limpiar tabla

            String linea;
            while (!(linea = in.readLine()).equals("FIN")) {
                String[] partes = linea.split(";");
                model.addRow(new Object[]{partes[0], partes[1], partes[2]});
            }

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "❌ Error: " + ex.getMessage());
        }
    }
}

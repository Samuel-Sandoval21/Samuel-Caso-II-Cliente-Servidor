/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.libreriadigital.Cliente;

import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.net.Socket;
import javax.swing.JFrame;

/**
 *
 * @author HP
 */
public class RegistrarLibroForm extends JFrame {

    private JTextField tfISBN, tfTitulo, tfAutor, tfEditorial, tfFecha, tfStock, tfPrecio, tfCategoria;
    private JTextArea taDescripcion;
    private JButton btnEnviar;

    public RegistrarLibroForm() {
        setTitle("📖 Registro de Nuevo Libro");
        setSize(450, 500);
        setLocationRelativeTo(null);
        setLayout(new GridLayout(10, 2));

        tfISBN = new JTextField();
        tfTitulo = new JTextField();
        tfAutor = new JTextField();
        tfEditorial = new JTextField();
        tfFecha = new JTextField("YYYY-MM-DD");
        tfStock = new JTextField();
        tfPrecio = new JTextField();
        tfCategoria = new JTextField();
        taDescripcion = new JTextArea(3, 20);
        btnEnviar = new JButton("Guardar Libro");

        add(new JLabel("ISBN:"));
        add(tfISBN);
        add(new JLabel("Título:"));
        add(tfTitulo);
        add(new JLabel("Autor:"));
        add(tfAutor);
        add(new JLabel("Editorial:"));
        add(tfEditorial);
        add(new JLabel("Fecha publicación:"));
        add(tfFecha);
        add(new JLabel("Stock:"));
        add(tfStock);
        add(new JLabel("Precio:"));
        add(tfPrecio);
        add(new JLabel("Categoría:"));
        add(tfCategoria);
        add(new JLabel("Descripción:"));
        add(new JScrollPane(taDescripcion));
        add(btnEnviar);

        btnEnviar.addActionListener(e -> enviarLibro());
    }

    private void enviarLibro() {
        try (Socket socket = new Socket("localhost", 1234); PrintWriter out = new PrintWriter(socket.getOutputStream(), true)) {

            out.println("registrar_libro");
            out.println(tfISBN.getText());
            out.println(tfTitulo.getText());
            out.println(tfAutor.getText());
            out.println(tfEditorial.getText());
            out.println(tfFecha.getText());
            out.println(tfStock.getText());
            out.println(tfPrecio.getText());
            out.println(tfCategoria.getText());
            out.println(taDescripcion.getText());

            JOptionPane.showMessageDialog(this, "📘 Libro enviado al servidor correctamente.");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "❌ Error al enviar: " + ex.getMessage());
        }
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.libreriadigital.Cliente;

import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.net.Socket;
import javax.swing.JFrame;

/**
 *
 * @author HP
 */
public class EventoLibroForm extends JFrame {

    private JTextField tfIdLibro, tfDetalles;
    private JComboBox<String> cbTipoEvento;
    private JButton btnEnviar;

    public EventoLibroForm() {
        setTitle("📌 Registrar Evento para Libro");
        setSize(400, 250);
        setLocationRelativeTo(null);
        setLayout(new GridLayout(4, 2));

        cbTipoEvento = new JComboBox<>(new String[]{"ACTUALIZACION PRECIO", "CAMBIO STOCK", "RECLASIFICACION"});
        tfIdLibro = new JTextField();
        tfDetalles = new JTextField();
        btnEnviar = new JButton("Guardar Evento");

        add(new JLabel("ID Libro:"));
        add(tfIdLibro);
        add(new JLabel("Tipo Evento:"));
        add(cbTipoEvento);
        add(new JLabel("Detalles:"));
        add(tfDetalles);
        add(new JLabel(""));
        add(btnEnviar);

        btnEnviar.addActionListener(e -> enviarEvento());
    }

    private void enviarEvento() {
        try (Socket socket = new Socket("localhost", 1234); PrintWriter out = new PrintWriter(socket.getOutputStream(), true)) {
            out.println("registrar_evento");
            out.println(tfIdLibro.getText());
            out.println(cbTipoEvento.getSelectedItem().toString());
            out.println(tfDetalles.getText());

            JOptionPane.showMessageDialog(this, "✅ Evento enviado con éxito.");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "❌ Error: " + ex.getMessage());
        }
    }
}

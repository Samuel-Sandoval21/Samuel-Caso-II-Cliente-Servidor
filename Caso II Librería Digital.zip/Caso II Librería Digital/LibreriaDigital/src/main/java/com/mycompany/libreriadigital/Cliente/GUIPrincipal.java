/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.libreriadigital.Cliente;

import javax.swing.*;
import java.awt.event.*;
import javax.swing.JFrame;

/**
 *
 * @author HP
 */
public class GUIPrincipal extends JFrame {

    public GUIPrincipal() {
        setTitle("📚 Letra Viva - Panel Principal");
        setSize(400, 300);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JButton btnRegistrar = new JButton("📖 Registrar Libro");
        JButton btnEditar = new JButton("📝 Editar/Eliminar Libro");
        JButton btnEvento = new JButton("📌 Asociar Evento");
        JButton btnHistorial = new JButton("📊 Ver Historial");

        btnRegistrar.addActionListener(e -> new RegistrarLibroForm().setVisible(true));
        btnEditar.addActionListener(e -> new EditarLibroForm().setVisible(true));
        btnEvento.addActionListener(e -> new EventoLibroForm().setVisible(true));
        btnHistorial.addActionListener(e -> new HistorialEventosPanel().setVisible(true));

        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.add(btnRegistrar);
        panel.add(btnEditar);
        panel.add(btnEvento);
        panel.add(btnHistorial);

        add(panel);
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.libreriadigital.Cliente;

import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.net.Socket;
import javax.swing.JFrame;

/**
 *
 * @author HP
 */
public class EditarLibroForm extends JFrame {

    private JTextField tfISBN, tfNuevoPrecio, tfNuevoStock;
    private JButton btnActualizar, btnEliminar;

    public EditarLibroForm() {
        setTitle("📝 Editar / Eliminar Libro");
        setSize(400, 200);
        setLocationRelativeTo(null);
        setLayout(new GridLayout(4, 2));

        tfISBN = new JTextField();
        tfNuevoPrecio = new JTextField();
        tfNuevoStock = new JTextField();
        btnActualizar = new JButton("Actualizar");
        btnEliminar = new JButton("Eliminar");

        add(new JLabel("ISBN del libro:"));
        add(tfISBN);
        add(new JLabel("Nuevo precio:"));
        add(tfNuevoPrecio);
        add(new JLabel("Nuevo stock:"));
        add(tfNuevoStock);
        add(btnActualizar);
        add(btnEliminar);

        btnActualizar.addActionListener(e -> actualizar());
        btnEliminar.addActionListener(e -> eliminar());
    }

    private void actualizar() {
        try (Socket socket = new Socket("localhost", 1234); PrintWriter out = new PrintWriter(socket.getOutputStream(), true)) {
            out.println("editar_libro");
            out.println(tfISBN.getText());
            out.println(tfNuevoPrecio.getText());
            out.println(tfNuevoStock.getText());

            JOptionPane.showMessageDialog(this, "✅ Libro actualizado.");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "❌ Error: " + ex.getMessage());
        }
    }

    private void eliminar() {
        try (Socket socket = new Socket("localhost", 1234); PrintWriter out = new PrintWriter(socket.getOutputStream(), true)) {
            out.println("eliminar_libro");
            out.println(tfISBN.getText());

            JOptionPane.showMessageDialog(this, "🗑️ Libro eliminado.");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "❌ Error: " + ex.getMessage());
        }
    }
}

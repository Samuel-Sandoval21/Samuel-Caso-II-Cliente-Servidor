/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.libreriadigital.Cliente;

/**
 *
 * @author HP
 */
public class Cliente {

    public static void main(String[] args) {
        javax.swing.SwingUtilities.invokeLater(() -> {
            GUIPrincipal gui = new GUIPrincipal();
            gui.setVisible(true);
        });
    }
    
}

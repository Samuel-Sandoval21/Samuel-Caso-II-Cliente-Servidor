/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.libreriadigitalCliente.Modelo;

import java.io.Serializable;

/**
 *
 * @author HP
 */
public class EventoLibro implements Serializable {

    private int idEvento;
    private int idLibro;
    private String tipoEvento;
    private String fechaEvento;
    private String detalles;

    public EventoLibro(int idEvento, int idLibro, String tipoEvento, String fechaEvento, String detalles) {
        this.idEvento = idEvento;
        this.idLibro = idLibro;
        this.tipoEvento = tipoEvento;
        this.fechaEvento = fechaEvento;
        this.detalles = detalles;
    }

    public EventoLibro(int idLibro, String tipoEvento, String fechaEvento, String detalles) {
        this.idLibro = idLibro;
        this.tipoEvento = tipoEvento;
        this.fechaEvento = fechaEvento;
        this.detalles = detalles;
    }

    // Getters y Setters
    public int getIdEvento() {
        return idEvento;
    }

    public void setIdEvento(int idEvento) {
        this.idEvento = idEvento;
    }

    public int getIdLibro() {
        return idLibro;
    }

    public void setIdLibro(int idLibro) {
        this.idLibro = idLibro;
    }

    public String getTipoEvento() {
        return tipoEvento;
    }

    public void setTipoEvento(String tipoEvento) {
        this.tipoEvento = tipoEvento;
    }

    public String getFechaEvento() {
        return fechaEvento;
    }

    public void setFechaEvento(String fechaEvento) {
        this.fechaEvento = fechaEvento;
    }

    public String getDetalles() {
        return detalles;
    }

    public void setDetalles(String detalles) {
        this.detalles = detalles;
    }
}
